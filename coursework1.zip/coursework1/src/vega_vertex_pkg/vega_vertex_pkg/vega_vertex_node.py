import rclpy
from rclpy.node import Node
from vega_vertex_interfaces.msg import TestMessage  # Import custom message type

class VegaVertexNode(Node):
    def __init__(self):
        super().__init__('vega_vertex_node')
        self.publisher_ = self.create_publisher(TestMessage, '/robot/task_space_pose', 10)
        self.timer = self.create_timer(1.0, self.publish_message)  # Publish every second
        self.get_logger().info('Vega Vertex Node is up and running.')

    def publish_message(self):
        msg = TestMessage()
        msg.data = 42  # Arbitrary data for testing
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: {msg.data}')


def main(args=None):
    rclpy.init(args=args)
    node = VegaVertexNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

