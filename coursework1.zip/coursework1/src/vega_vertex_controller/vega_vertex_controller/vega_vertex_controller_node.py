import rclpy
from rclpy.node import Node
from vega_vertex_interfaces.msg import TestMessage

class VegaVertexControllerNode(Node):
    def __init__(self):
        super().__init__('vega_vertex_controller_node')
        self.subscription = self.create_subscription(
            TestMessage,
            '/robot/task_space_pose',
            self.listener_callback,
            10)
        self.get_logger().info('Vega Vertex Controller Node is up and listening.')

    def listener_callback(self, msg):
        self.get_logger().info(f'Received data: {msg.data}')


def main(args=None):
    rclpy.init(args=args)
    node = VegaVertexControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

